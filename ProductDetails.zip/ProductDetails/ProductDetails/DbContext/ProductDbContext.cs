﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace ProductDetails.DbContext
{
    public class ProductDbContext
    {
        private readonly IConfiguration _configuration;
        private readonly string _connection;

        public ProductDbContext(IConfiguration configuration)
        {
            _configuration = configuration;
            _connection = configuration.GetConnectionString("ConnectionDetails");
        }

        public IDbConnection CreateConnection() => new SqlConnection(_connection);

    }
}
