﻿using Dapper;
using Microsoft.EntityFrameworkCore.ValueGeneration.Internal;
using ProductDetails.DbContext;
using ProductDetails.Interface;
using ProductDetails.Models;


namespace ProductDetails.Repository
{
    public class ProductRepository : IProduct
    {
        private readonly ProductDbContext context;

        public ProductRepository(ProductDbContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<Product>> GetProducts()
        {
            var sql = $@"SELECT [ProductId],
                                [ProductName],
                                [Description],
                                [CreatedAt]
                                FROM
                                [Products]";

            using var connection = context.CreateConnection();
            return await connection.QueryAsync<Product>(sql);
        }

        public async Task<Product> GetProductById(int id)
        {
            var sql = $@"SELECT [ProductId],
                                [ProductName],
                                [Description],
                                [CreatedAt]
                             FROM
                                [Products]
                             WHERE
                                [ProductId]=@id";

            using var connection = context.CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<Product>(sql, new { id });

        }

        public async Task<Product> AddProduct(Product product)
        {
            var sql = $@"INSERT INTO [dbo].[Products]
                                ([ProductName],
                                [Description],
                                [CreatedAt])
                               Values
                                (@ProductName,
                                 @Description,
                                 @CreatedAt)";

            using var connection = context.CreateConnection();
            await connection.ExecuteAsync(sql, product);
            return product;
        }

        public async Task<Product> UpdateProduct(int id, Product product)
        {
            var sql = $@"UPDATE [dbo].[Products]
                 SET [ProductName] = @ProductName,
                     [Description] = @Description,
                     [CreatedAt] = @CreatedAt
                 WHERE [ProductId] = @Id";

            
            product.ProductId = id;

            using var connection = context.CreateConnection();
            await connection.ExecuteAsync(sql, new
            {
                Id = id,  // Pass the id parameter to the query
                product.ProductName,
                product.Description,
                product.CreatedAt
            });
            return product;
        }


        public async Task<Product> DeleteProduct(int id, Product product)
        {
            var sql = @"DELETE FROM [dbo].[Products] WHERE [ProductId] = @id";

            using var connection = context.CreateConnection();
            await connection.ExecuteAsync(sql, new { id });

          
            return null; 
        }


    }
}
