﻿using Microsoft.AspNetCore.Mvc;
using ProductDetails.Interface;
using ProductDetails.Models;

namespace ProductDetails.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProduct productRepository;

        public ProductController(IProduct productRepository)
        {
            this.productRepository = productRepository;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult AddProduct()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddProduct(Product product)
        {
            if (ModelState.IsValid)
            {
                product.CreatedAt = DateTime.Now;
                var addedProduct = await productRepository.AddProduct(product);
                TempData["SuccessMessage"] = "Product has been stored successfully.";
                return RedirectToAction("GetProducts", new { id = addedProduct.ProductId });
            }
            return View(product);
        }

        [HttpGet]
        public async Task<IActionResult> GetProducts()
        {
            var products = await productRepository.GetProducts();
            return View(products);
        }

        [HttpGet]
        public async Task<IActionResult> Details(int id)
        {
            var Product = await productRepository.GetProductById(id);
            return View(Product);
        }

        [HttpGet]
        public async Task<IActionResult> UpdateProduct(int id)
        {
            var Product = await productRepository.GetProductById(id);
            return View(Product);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateProduct(int id, Product product)
        {
            if (ModelState.IsValid)
            {
                product.CreatedAt = DateTime.Now;
                var Product = await productRepository.GetProductById(id);
                await productRepository.UpdateProduct(id, product);
                TempData["UpdateMessage"] = "Product has been successfully updated.";
                return RedirectToAction("GetProducts");
            }
            return View(product);
        }

        [HttpGet]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var Product = await productRepository.GetProductById(id);
            return View(Product);
        }

        [HttpPost]
        public async Task<IActionResult> DeleteProduct(int id, Product product)
        {
            var Product = await productRepository.GetProductById(id);
            await productRepository.DeleteProduct(id, product);
            TempData["DeleteMessage"] = "Product has been successfully Deleted!";
            return RedirectToAction("GetProducts");
        }

    }
}
